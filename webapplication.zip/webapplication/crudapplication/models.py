from django.db import models

class Employee(models.Model):
    eid=models.CharField(primary_key=True, max_length=20)
    ename=models.CharField(max_length=100)
    eemail=models.EmailField()
    econtact=models.CharField(max_length=15)
    class Meta:
        db_table="employee"

class blood_test(models.Model):
    blood_id=models.CharField(primary_key=True,max_length=8)
    HCV=models.BooleanField()
    HIV=models.BooleanField()
    HBsAg=models.BooleanField()
    Syphilis=models.BooleanField()
    MP=models.BooleanField()
    class Meta :
        db_table="blood_test"


class Bag(models.Model):
    bag_id=models.CharField(primary_key=True,max_length=8)
    blood_id=models.ForeignKey(blood_test,on_delete=models.CASCADE)
    blood_group=models.CharField(max_length=5)
    rh_type=models.CharField(max_length=5)
    amount=models.DecimalField(max_digits=8, decimal_places=2)
    stored_date=models.DateField()
    expired_date=models.DateField()
    class Meta :
        db_table="Bag"

class Bag_1(models.Model) :
    bag_id=models.CharField(primary_key=True,max_length=8)
    blood_id=models.ForeignKey(blood_test,on_delete=models.CASCADE)
    blood_group=models.CharField(max_length=5)
    rh_type =models.CharField(max_length=5)
    amount =models.DecimalField(max_digits=8, decimal_places=2)
    stored_date=models.DateField()
    expired_date =models.DateField()
    class Meta :
        db_table="Bag_1"














