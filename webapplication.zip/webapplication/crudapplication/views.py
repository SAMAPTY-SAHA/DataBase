from django.shortcuts import render,redirect
from crudapplication.forms import EmployeeForm,blood_testForm,BagForm,Bag_1Form
from crudapplication.models import Employee,blood_test,Bag,Bag_1

def emp(request):
    if request.method ==  "POST" :
        form = EmployeeForm(request.POST)
        if form.is_valid() :
            try:
                form.save()
                return redirect('/show')
            except :
                pass
    else :
        form = EmployeeForm()
    return render(request,"index.html",{'form' : form})



def show(request) :
    employees = Employee.objects.all()
    return render(request,"show.html",{'employees' : employees})

def edit(request,id):
    employee = Employee.objects.get(id=id)
    return render(request,"edit.html",{'employee' : employee})

def update(request,id):
    employee = Employee.objects.get(id=id)
    form =EmployeeForm(request.POST,instance=employee)
    if form.is_valid():
        form.save()
        return redirect('/show')
    return render(request,"edit.html",{'employee ' : employee})

def delete(request,id):
    employee = Employee.objects.get(id=id)
    employee.delete()
    return  redirect('/show')


def blood_test_Method(request):
    if request.method ==  "POST" :
        form = blood_testForm(request.POST)
        if form.is_valid() :
            try:
                form.save()
                return redirect('/show_blood_test')
            except :
                pass
    else :
        form = blood_testForm()
    return render(request,"blood_test.html",{'form' : form})

def show_blood_test(request) :
    blood_test_1 = blood_test.objects.all()
    return render(request,"show_blood_test.html",{'blood_test_1' : blood_test_1})

def bag_Method(request):
    if request.method ==  "POST" :
        form =BagForm(request.POST)
        if form.is_valid() :
            try:
                form.save()
                return redirect('/show_Bag')
            except :
                pass
    else :
        form = BagForm()
    return render(request,"Bag.html",{'form' : form})

def show_Bag(request) :
    bag_1 = Bag.objects.all()
    return render(request,"show_Bag.html",{'bag_1' : bag_1})

def bag_1_method(request):
    if request.method ==  "POST" :
        form = Bag_1Form(request.POST)
        if form.is_valid() :
            try:
                form.save()
                return redirect('/show_Bag_1')
            except :
                pass
    else :
        form = Bag_1Form()
    return render(request,"Bag_1.html",{'form' : form})


def show_bbag_1(request) :
    bag_1 = Bag_1.objects.all()
    return render(request,"show_Bag_1.html",{'bag' : bag_1})










