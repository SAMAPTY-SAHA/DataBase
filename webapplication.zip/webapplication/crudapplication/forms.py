from django import forms
from crudapplication.models import Employee,blood_test,Bag,Bag_1

class EmployeeForm(forms.ModelForm):
    class Meta :
        model = Employee
        fields = "__all__"

class blood_testForm(forms.ModelForm):
    class Meta :
        model =blood_test
        fields ="__all__"


class BagForm(forms.ModelForm) :
    class Meta :
        model=Bag
        fields="__all__"

class Bag_1Form(forms.ModelForm) :
    class Meta :
        model=Bag_1
        fields="__all__"
