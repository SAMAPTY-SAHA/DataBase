from django.apps import AppConfig


class CrudapplicationConfig(AppConfig):
    name = 'crudapplication'
